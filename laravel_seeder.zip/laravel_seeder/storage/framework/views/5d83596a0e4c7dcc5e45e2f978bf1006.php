<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title','rakaVai'); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header>
    <h1>Header</h1>
    
</header>

<div class="container">
    <div class="sidebar">
        
        <?php $__env->startSection('sidbar'); ?>
        <h2>Sidebar</h2>
        <p>This is the sidebar content.</p>
        <a href="/about">About</a>
        <a href="/news">News</a>
        <a href="/post">Post</a>
        <a href="/">Home</a>
        <?php echo $__env->yieldSection(); ?>
    </div>
    <div class="content">
        <?php if (! empty(trim($__env->yieldContent('content')))): ?>
            <?php echo $__env->yieldContent('content'); ?>
                
        <?php else: ?>
            <h2>No content found!</h2>
        <?php endif; ?>
      </div>
</div>

<footer>
    <p>Footer</p>
</footer>

</body>
</html>
<?php /**PATH D:\laravel\example-app\resources\views/layout/masterlayout.blade.php ENDPATH**/ ?>
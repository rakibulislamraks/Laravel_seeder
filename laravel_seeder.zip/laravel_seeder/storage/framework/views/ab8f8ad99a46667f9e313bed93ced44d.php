

<?php $__env->startSection('content'); ?>
    <h1>post Page</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime temporibus omnis magni placeat laudantium amet necessitatibus recusandae aspernatur iure provident velit labore, laborum, in beatae libero rem ea veniam aperiam.</p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    Post
<?php $__env->stopSection(); ?>
<h1>Id : <?php echo e($id); ?></h1>

<?php echo $__env->make('layout.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\example-app\resources\views/posts.blade.php ENDPATH**/ ?>
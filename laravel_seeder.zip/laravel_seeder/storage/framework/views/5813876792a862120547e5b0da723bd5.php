
<?php $__env->startSection('title'); ?>
    News
<?php $__env->stopSection(); ?> 
<h1>User Details</h1>
<h4>Name: <?php echo e($id['name']); ?></h4>
<h4>city: <?php echo e($id['city']); ?></h4>
<h4>phone: <?php echo e($id['phone']); ?></h4><?php /**PATH D:\laravel\example-app\resources\views/news.blade.php ENDPATH**/ ?>